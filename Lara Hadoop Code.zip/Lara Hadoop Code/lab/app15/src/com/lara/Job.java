package com.lara;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
public class Job extends Configured implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf conf = new JobConf(getConf(), Job.class);
		conf.setJobName("partioner");
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(Text.class);
		conf.setMapperClass(MyMapper.class);
		conf.setReducerClass(MyReducer.class);
		conf.setPartitionerClass(MyPartitioner.class);
		conf.setNumReduceTasks(6);
		FileInputFormat.addInputPath(conf, new Path("emp.txt"));
		FileOutputFormat.setOutputPath(conf, new Path("r24"));
		JobClient.runJob(conf);
		return 0;	
	}
}

