package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyReducer extends MapReduceBase 
implements Reducer<Text, Text, Text, Text>
{
	public void reduce(Text key,
			   Iterator<Text> values,
			   OutputCollector<Text, Text> output,
			   Reporter rp) throws IOException
	{
		String s1, s2;
		int sumSalary = 0;
		int age = 0;
		while(values.hasNext())
		{
			s1 = values.next().toString();
			s2 = s1.substring(s1.lastIndexOf(',') + 1).trim();
			sumSalary += Integer.parseInt(s2);
			age = Integer.parseInt(s1.substring(s1.indexOf(',') + 1, s1.lastIndexOf(',')));
		}
		String ageRange = null;
		if(age >= 20 && age < 30)
		{
			ageRange = " Age B/W 20 and 30";
		}
		else if(age >= 30 && age < 40)
		{
			ageRange = " Age B/W 30 and 40";
		}
		else if(age >= 40 && age < 50)
		{
			ageRange = " Age B/W 40 and 50";
		}
		output.collect(new Text(key.toString() + ageRange), new Text("sum:" + sumSalary));	}	
}
