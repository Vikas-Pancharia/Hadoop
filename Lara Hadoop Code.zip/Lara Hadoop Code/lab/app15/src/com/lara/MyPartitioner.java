package com.lara;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;
public class MyPartitioner implements Partitioner<Text, Text>
{
	@Override
	public int getPartition(Text arg0, Text arg1, int arg2)
	{
		String gender = arg0.toString();
		String nameAgeSalary = arg1.toString();
		String age = nameAgeSalary.split(",")[1];
		int ageInt = Integer.parseInt(age);
		if((ageInt > 20 && ageInt < 30) && "male".equals(gender))
		{
			return 0;
		}
		else if((ageInt > 20 && ageInt < 30) && "female".equals(gender))
		{
			return 1 % arg2;
		}		
		else if((ageInt > 30 && ageInt < 40) && "male".equals(gender))
		{
			return 2 % arg2;
		}
		else if((ageInt > 30 && ageInt < 40) && "female".equals(gender))
		{
			return 3 % arg2;
		}
		else if((ageInt > 40 && ageInt < 50) && "male".equals(gender))
		{
			return 4 % arg2;
		}
		else if((ageInt > 40 && ageInt < 50) && "female".equals(gender))
		{
			return 5 % arg2;
		}
		else
		{
			return 0;
		}
	}
	@Override
	public void configure(JobConf arg0) {
		arg0.setPartitionerClass(this.getClass());
		
	}
}
