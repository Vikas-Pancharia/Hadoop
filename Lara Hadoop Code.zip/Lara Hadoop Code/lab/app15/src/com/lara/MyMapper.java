package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, Text> output, 
			Reporter rp) throws IOException 
	{
		String s1 = value.toString();
		String[] words = s1.split(",");
		String gender = words[2].trim();
		String nameAgeSalary = words[0].trim() + "," + words[1].trim() + "," + words[3].trim();
		output.collect(new Text(gender), new Text(nameAgeSalary));		
	}
}
