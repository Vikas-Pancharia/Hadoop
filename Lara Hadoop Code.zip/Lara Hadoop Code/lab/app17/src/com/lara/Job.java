package com.lara;
import java.net.URI;
import org.apache.hadoop.io.*;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;

public class Job extends Configured 
implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf job = new JobConf(getConf(), Job.class);
		job.setJobName("Distributed Cache");
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapperClass(MyMapper.class);
		FileInputFormat.addInputPath(job, new Path("employee.txt"));
		FileOutputFormat.setOutputPath(job, new Path("results2"));
		DistributedCache.addCacheFile(new URI("dept.properties"), job);
		JobClient.runJob(job);
		return 0;
	}
}
