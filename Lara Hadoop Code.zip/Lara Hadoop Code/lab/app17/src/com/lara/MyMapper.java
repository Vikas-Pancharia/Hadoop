package com.lara;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase
implements Mapper<LongWritable, Text, IntWritable, Text>
{
	Properties dept = new Properties();
	@Override
	public void configure(JobConf job) 
	{
		try
		{
			Path[] cacheFilesLocal = 
					DistributedCache.getLocalCacheFiles(job);
			for(Path p1 : cacheFilesLocal)
			{
				if("dept.properties".equals(p1.getName()))
				{
					dept.load(new FileInputStream("dept.properties"));
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	public void map(LongWritable key, Text value, 
			OutputCollector<IntWritable, Text> out,
			Reporter rp) throws IOException
	{
		String line = value.toString();
		String[] data = line.split(",");
		String department = dept.getProperty(data[5]);
		String empData = data[1] + "\t" + department;
		int empId = Integer.parseInt(data[0]);
		out.collect(new IntWritable(empId), new Text(empData));
	}
}
