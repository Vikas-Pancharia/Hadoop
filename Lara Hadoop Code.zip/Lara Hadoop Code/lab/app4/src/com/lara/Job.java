package com.lara;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
public class Job extends Configured implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf conf = new JobConf(getConf(), Job.class);
		conf.setJobName("example-3");
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(IntWritable.class);
		conf.setMapperClass(MyMapper.class);
		conf.setReducerClass(MyReducer.class);
		FileInputFormat.addInputPath(conf, new Path("hello.txt"));
		FileOutputFormat.setOutputPath(conf, new Path("r5"));
		JobClient.runJob(conf);
		return 0;	
	}
}

