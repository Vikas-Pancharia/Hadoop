package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		output.collect(new Text("lines:"), new IntWritable(1));
		String s1 = value.toString();
		String words[] = s1.split(" ");
		output.collect(new Text("words:"), new IntWritable(words.length));
		for(String word : words)
		{
			output.collect(new Text("chars:"), new IntWritable(word.length()));
		}
	}
}

