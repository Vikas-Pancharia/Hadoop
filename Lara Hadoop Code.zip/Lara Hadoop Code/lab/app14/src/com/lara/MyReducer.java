package com.lara;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

public class MyReducer extends MapReduceBase 
implements Reducer<PersonKey, OrderValue, PersonKey, IntWritable>
{
	@Override
	public void reduce(PersonKey arg0, Iterator<OrderValue> arg1,
			OutputCollector<PersonKey, IntWritable> arg2, Reporter arg3)
			throws IOException
	{
		int sum = 0;
		OrderValue value = null;
		while(arg1.hasNext())
		{
			value = arg1.next();
			sum += (value.getProductPrice() * value.getOrderQuantity()); 
		}
		arg2.collect(arg0, new IntWritable(sum));
	}
}
