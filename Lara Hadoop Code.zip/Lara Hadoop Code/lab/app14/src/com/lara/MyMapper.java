package com.lara;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class MyMapper extends MapReduceBase 
		implements Mapper<LongWritable, Text, PersonKey, OrderValue>
{
	@Override
	public void map(LongWritable arg0, Text arg1,
			OutputCollector<PersonKey, OrderValue> arg2, Reporter arg3)
			throws IOException
	{
		String line = arg1.toString();
		if(line != null && line.length() != 0)
		{
			String[] words = line.split("\t");
			String firstName = words[1].trim();
			String lastName = words[2].trim();
			String productPrice = words[3].trim();
			String orderQuantity = words[4].trim();

			PersonKey pk = new PersonKey(firstName, lastName);
			OrderValue value = new OrderValue(Integer.parseInt(productPrice), 
											  Integer.parseInt(orderQuantity));			
			arg2.collect(pk, value);
		}
	}
}
