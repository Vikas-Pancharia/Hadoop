package com.lara;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
public class Job extends Configured implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf conf = new JobConf(getConf(), Job.class);
		conf.setJobName("key, value");
		conf.setMapOutputKeyClass(PersonKey.class);
		conf.setMapOutputValueClass(OrderValue.class);
		conf.setOutputKeyClass(PersonKey.class);
		conf.setOutputValueClass(IntWritable.class);
		conf.setMapperClass(MyMapper.class);
		conf.setReducerClass(MyReducer.class);
		FileInputFormat.addInputPath(conf, new Path("person.txt"));
		FileOutputFormat.setOutputPath(conf, new Path("r21"));
		JobClient.runJob(conf);
		return 0;	
	}
}

