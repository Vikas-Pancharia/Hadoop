package com.lara;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class PersonKey implements WritableComparable<PersonKey>
{
	private String firstName;
	private String lastName;
	
	public PersonKey(String firstName, String lastName)
	{
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public PersonKey()
	{
		
	}
	
	@Override
	public void write(DataOutput arg0) throws IOException
	{
		arg0.writeUTF(firstName);
		arg0.writeUTF(lastName);		
	}
	
	@Override
	public void readFields(DataInput arg0) throws IOException 
	{
		firstName = arg0.readUTF();
		lastName = arg0.readUTF();
	}
	
	@Override
	public int compareTo(PersonKey o) 
	{
		int i = firstName.compareTo(o.firstName);
		i += lastName.compareTo(o.lastName);
		return i;
	}
	
	@Override
	public int hashCode()
	{
		int hash = firstName.hashCode();
		hash += lastName.hashCode();
		return hash;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		return ((obj instanceof PersonKey)  &&
				firstName.equals(((PersonKey)obj).firstName) &&
				lastName.equals(((PersonKey)obj).lastName));
	}
	
	@Override
	public String toString()
	{
		return "first name:" + firstName + ", last name:" + lastName;
	}
}
