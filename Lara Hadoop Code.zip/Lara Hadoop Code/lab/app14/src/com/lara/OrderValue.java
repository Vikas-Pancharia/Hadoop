package com.lara;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class OrderValue implements Writable
{
	private int productPrice;
	private int orderQuantity;
	
	public OrderValue()
	{
		
	}
	public OrderValue(int productPrice, int orderQuantity)
	{
		this.productPrice = productPrice;
		this.orderQuantity = orderQuantity;
	}
	
	@Override
	public void write(DataOutput arg0) throws IOException
	{
		arg0.writeInt(productPrice);
		arg0.writeInt(orderQuantity);
	}
	
	@Override
	public void readFields(DataInput arg0) throws IOException
	{
		productPrice = arg0.readInt();
		orderQuantity = arg0.readInt();
	}
	
	
	public int getProductPrice() {
		return productPrice;
	}
	
	public int getOrderQuantity() {
		return orderQuantity;
	}
	
	
}
