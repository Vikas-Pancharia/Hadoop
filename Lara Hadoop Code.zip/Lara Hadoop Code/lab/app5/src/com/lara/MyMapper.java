package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		output.collect(new Text("lines:"), new IntWritable(1));
		String s1 = value.toString();
		String words[] = s1.split(" ");
		output.collect(new Text("words:"), new IntWritable(words.length));
		char c1;
		int v1;
		String charType;
		for(String word : words)
		{
			output.collect(new Text("chars:"), 
				       new IntWritable(word.length()));
			for(int i = 0; i < word.length(); i++)
			{
				c1 = word.charAt(i);
				v1 = c1;
				if(v1 >= 48 && v1 <= 57)
				{
					charType = "digit";
				} 
				else if(v1 >= 65 && v1 <= 90)
				{
					charType = "Uppercase";
				}

				else if(v1 >= 97 && v1 <= 122)
				{
					charType = "LOwercase";
				}
				else
				{
					charType = "SPL Char";
				}
				output.collect(new Text(charType), 
				       new IntWritable(1));
			}
			
		}
	}
}

