package com.lara;

public class M 
{
	public static void main(String[] args) 
	{
		char c1 = 'a';
		char c2 = 'z';
		char c3 = 'A';
		char c4 = 'Z';
		char c5 = '0';
		char c6 = '9';
		int v1 = c1;
		int v2 = c2;
		int v3 = c3;
		int v4 = c4;
		int v5 = c5;
		int v6 = c6;
		System.out.println("a:" + v1);
		System.out.println("z:" + v2);
		System.out.println("A:" + v3);
		System.out.println("Z:" + v4);
		System.out.println("0:" + v5);
		System.out.println("9:" + v6);
		
		
		
	}
}
