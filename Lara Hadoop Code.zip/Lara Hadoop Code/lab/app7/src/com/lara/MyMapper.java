package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		String s1 = value.toString();
		String words[] = s1.split(" ");
		String s2;
		char[] c1;
		for(String word : words)
		{
			c1 = word.toCharArray();
			Arrays.sort(c1);
			s2 = new String(c1);
			output.collect(new Text(s2), new IntWritable(1));
		}
	}
}

