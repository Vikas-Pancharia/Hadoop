package com.lara;

import java.util.Arrays;

public class M 
{
	public static void main(String[] args) 
	{
l
	}
}
