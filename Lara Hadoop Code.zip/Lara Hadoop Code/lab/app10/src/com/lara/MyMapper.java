package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, IntWritable, DoubleWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<IntWritable, DoubleWritable> output, 
			Reporter rp) throws IOException 
	{
		String s1 = value.toString();
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd");
		Date date = null;
		String strDate = null;
		String strAvg = null;
		Calendar cal = Calendar.getInstance();
		int week = 0;
		double avg = 0.0;
		if(s1 != null && s1.length() != 0)
		{
			strDate = s1.substring(6, 14);
			strAvg = s1.substring(62, 69);
			avg = Double.parseDouble(strAvg);
			try
			{
				date = sf.parse(strDate);
			}
			catch(ParseException ex)
			{
			}
			cal.setTime(date);
			week = cal.get(Calendar.WEEK_OF_YEAR);			
			output.collect(new IntWritable(week), 
				       new DoubleWritable(avg));
		}
	}
}

