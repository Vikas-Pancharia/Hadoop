package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;

public class MyReducer extends MapReduceBase 
implements Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>
{
	public void reduce(IntWritable key,
			   Iterator<DoubleWritable> values,
			   OutputCollector<IntWritable, DoubleWritable> output,
			   Reporter rp) throws IOException
	{
		double sum = 0;
		int count = 0;
		while(values.hasNext())
		{
			sum += values.next().get();
			count ++;
		}
		double avg = sum/count;
		output.collect(key, new DoubleWritable(avg));
	}	
}

