package com.lara;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Z5 
{
	public static void main(String[] args) 
	throws Exception
	{
		
		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
		String s1 = "2014-03-24";
		Date d1 = sd.parse(s1);
		System.out.println(d1);		
		
		
		/*
		SimpleDateFormat sd = new SimpleDateFormat("yy-MM-dd hh:mm:ss:SSSaa");
		String s1 = "14-03-24 08:12:23:345PM";
		Date d1 = sd.parse(s1);
		System.out.println(d1);		
		*/
		/*
		SimpleDateFormat sd = new SimpleDateFormat("dd.MM.yy HH:mm:ss:SSS");
		String s1 = "01.11.14 16:12:23:345";
		Date d1 = sd.parse(s1);
		System.out.println(d1);		
		*/
	}
}

/*
		 y  	==> year
		 M	==> Month
		 d	==> day in month
		 H	==> Hour in a day (0 - 23)
		 h	==> Hour in a day (1 -12)
		 m  	==> Minute in hour
		 s  	==> Second in minute
		 S	==> Millisecond
		 a  	==> am/pm
		 note : all are case sensitive
*/






