package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, LongWritable, Text>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<LongWritable, Text> output, 
			Reporter rp) throws IOException 
	{
		output.collect(key, value);
	}
}

