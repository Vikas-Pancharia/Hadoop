package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;

public class MyReducer extends MapReduceBase 
implements Reducer<LongWritable, Text, LongWritable, Text>
{
	public void reduce(LongWritable key,
			   Iterator<Text> values,
			   OutputCollector<LongWritable, Text> output,
			   Reporter rp) throws IOException
	{
		values.hasNext();
		output.collect(key, values.next());
	}	
}

