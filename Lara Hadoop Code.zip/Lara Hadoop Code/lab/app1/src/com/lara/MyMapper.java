package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		String s1 = value.toString();
		String[] words = s1.split(" ");
		for(String word : words)
		{
			output.collect(new Text(word), new IntWritable(1));
		}
	}
}

