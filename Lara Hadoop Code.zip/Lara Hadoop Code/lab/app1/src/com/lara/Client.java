package com.lara;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;
public class Client
{
	public static void main(String[] args) throws Exception
	{
		ToolRunner.run(new Configuration(), new Job(), args);
	}
}

