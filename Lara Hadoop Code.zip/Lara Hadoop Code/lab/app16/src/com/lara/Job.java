package com.lara;
import org.apache.hadoop.io.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapred.lib.MultipleInputs;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;
public class Job extends Configured 
implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf job = new JobConf(getConf(), Job.class);
		job.setJobName("reduce side join");
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);
		MultipleInputs.addInputPath(job, new Path("transactions.txt"), TextInputFormat.class, TxMapper.class);
		MultipleInputs.addInputPath(job, new Path("customer.txt"), TextInputFormat.class, CustMapper.class);
		job.setReducerClass(MyReducer.class);
		FileOutputFormat.setOutputPath(job, new Path("results1"));
		JobClient.runJob(job);
		return 0;
	}
}
