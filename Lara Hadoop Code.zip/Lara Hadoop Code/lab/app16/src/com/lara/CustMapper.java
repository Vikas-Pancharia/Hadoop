package com.lara;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import java.io.*;
import java.util.*;
public class CustMapper extends MapReduceBase
implements Mapper<LongWritable, Text, IntWritable, Text>
{
	public void map(LongWritable key, Text value, 
			OutputCollector<IntWritable, Text> out,
			Reporter rp) throws IOException
	{
		String line = value.toString();
		String[] data = line.split(",");
		String id = data[0];
		int custId = Integer.parseInt(id);
		String name = data[1];
		out.collect(new IntWritable(custId), new Text("Cust:" + name));
	}
}
