package com.lara;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import java.io.*;
import java.util.*;
public class MyReducer extends MapReduceBase
implements Reducer<IntWritable, Text, IntWritable, Text>
{
	public void reduce(IntWritable key, Iterator<Text> values, 
			OutputCollector<IntWritable, Text> out,
			Reporter rp) throws IOException
	{
		int sum = 0;
		String custName = null;
		String value = null;
		while(values.hasNext())
		{
			value = values.next().toString();
			if(value.startsWith("Cust:"))
			{
				custName = value.substring(value.indexOf(":") + 1);
			}
			else
			{
				sum += Integer.parseInt(value.substring(value.indexOf(":") + 1));
			}
		}
		out.collect(key, new Text(custName + ":" + sum));
	}
}
