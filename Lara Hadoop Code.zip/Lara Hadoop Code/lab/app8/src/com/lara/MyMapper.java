package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, Text>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, Text> output, 
			Reporter rp) throws IOException 
	{
		String s1 = value.toString();
		if(s1 != null && s1.length() != 0)
		{
			String stNo = s1.substring(0, 5);
			String date = s1.substring(6, 14);
			String max = s1.substring(38, 45);
			String min = s1.substring(46, 53);	
			output.collect(new Text(stNo + ":" + date), 
				       new Text("min:" + min + ", max:" + max));
		}
	}
}

