package com.lara;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
public class Job extends Configured implements Tool
{
	public int run(String[] args) throws Exception
	{
		JobConf conf = new JobConf(getConf(), Job.class);
		conf.setJobName("example-6");
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(Text.class);
		conf.setMapperClass(MyMapper.class);
		for(int i = 0; i < args.length - 1; i++)
		{
			FileInputFormat.addInputPath(conf, new Path(args[i]));
		}
		FileOutputFormat.setOutputPath(conf, new Path(args[args.length - 1]));
		JobClient.runJob(conf);
		return 0;	
	}
}

