package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		String line = value.toString();
		if(line != null && line.length() != 0)
		{
			String strAge = line.substring(0, line.indexOf(','));
			int age = Integer.parseInt(strAge);
			String s1 = null;
			if(age < 20)
			{
				s1 = "age is less than to 20";
			}
			else if(age >= 20 && age < 30)
			{
				s1 = "age in between 20 and 30:";
			}
			else if(age >= 30 && age < 40)
			{
				s1 = "age in between 30 and 40:";
			}
			else if(age >= 40 && age < 50)
			{
				s1 = "age in between 40 and 50:";
			}
			else if(age >= 50 && age < 60)
			{
				s1 = "age in between 50 and 60:";
			}
			else if(age >= 60)
			{
				s1 = "age greater than or equal to 60";
			}
			output.collect(new Text(s1), 
				       new IntWritable(1));
		}
	}
}

