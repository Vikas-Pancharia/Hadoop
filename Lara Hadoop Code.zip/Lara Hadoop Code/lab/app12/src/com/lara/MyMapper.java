package com.lara;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.io.*;
import java.io.*;
import java.util.*;
public class MyMapper extends MapReduceBase 
implements Mapper<LongWritable, Text, Text, IntWritable>
{
	public void map(LongWritable key, 
			Text value, 
			OutputCollector<Text, IntWritable> output, 
			Reporter rp) throws IOException 
	{
		String line = value.toString();
		if(line != null && line.length() != 0)
		{
			String[] fields = line.split(",");
			String workClass = fields[1].trim();
			output.collect(new Text(workClass), 
				       new IntWritable(1));
		}
	}
}

